# Exception handling
try:
   fh = open("testfile", "r")
except IOError as e:
   print("Error: {}".format(e))

# Multiple exception handling
try:
   i = 10//0
except (ArithmeticError, Exception) as e:
   print("Error: {}".format(e))

# User defined exception or exception customization
class MyError(Exception):

    def __init__(self, arg):
        self.arg = arg


try:
   # do something
    raise MyError("My own Exception")
except MyError as e:
    print('Error: ',e.arg)
