class Sample:
#
#     def __init__(self, var):
#         self.set(var)
#
#     def set(self, val):
#         self.__a=val
#
#     # def get(self):
#     #     return self.__a
#
#     @property
#     def get(self):
#         return self.__a
#
# sample = Sample(10)
# print(sample.get)

    def __init__(self, var):
        ## calling the set_a() method to set the value 'a' by checking certain conditions
        self.__set_a(var)

    ## getter method to get the properties using an object
    def __get_a(self):
        return self.__a

    ## setter method to change the value 'a' using an object
    def __set_a(self, var):
        self.__a = var

    def __del_a(self):
        del self.__a

    a = property(__get_a, __set_a, __del_a)


obj = Sample(12)
print(obj.a)
