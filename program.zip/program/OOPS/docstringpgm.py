class Kettle():
    """ WelCome new year
 With full of joy *:* """

    def __init__(self, name, price):
        """ With full of joy :)* """
        self.name = name
        self.price = price

    def print_docstring(self):
        """ With full of joy :)> """


if __name__ == '__main__':
    song1 = Kettle("New Year", 2020)
    # print("{} {}!!!".format(song1.name, song1.price))
    with open("content", "w") as contentfile:
        print(Kettle.__doc__, file=contentfile)
        print(Kettle.__init__.__doc__, file=contentfile)
        print(Kettle.print_docstring.__doc__, file=contentfile)

