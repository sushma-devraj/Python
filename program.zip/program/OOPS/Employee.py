class Employee:
    def __init__(self, n, a, s):
        self.__set__emp(n, a, s)

    def __set__emp(self, n, a, s):
        self.__name = n
        self.__age = a
        self.__salary = s

    def __get__emp(self):
        print("Employee name: {}, age: {}, salary: {}".format(self.__name, self.__age, self.__salary))

    emp=property(__get__emp)  # To access private method

if __name__ == '__main__':
    emp1 = Employee("Sonu", 24, 25000)
    emp1.emp
