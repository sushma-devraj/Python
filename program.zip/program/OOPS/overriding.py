class Employee:

    def message(self):
        print('This message is from Employee Class')

class Department(Employee):

    def message(self):
        super().message()
        print('This Department class is inherited from Employee')

emp = Employee()
emp.message()
print('*' * 60)
dept = Department()
dept.message()
