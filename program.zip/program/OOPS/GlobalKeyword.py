a = 10  # Global variable


def sample():
    a = 20
    print("a inside sample(): {}".format(a))


sample()
print("a outside: {}".format(a))

#############################################
a1 = 20


def sample1():
    global a1
    a1 += 30
    print("a inside sample(): {}".format(a1))


sample1()
print("a outside: {}".format(a1))
