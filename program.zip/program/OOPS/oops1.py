
# class Kettle(object):
#
#     power_source = "Electricity" # Class atrributes (like static field)
#
#     def __init__(self, name, price):
#         self.name = name
#         self.price = price
#         self.on = False
#
#     def switch_on(self):  # Class method which can access the class attributes
#         self.on = True
#         return self.on
#
#
# kenwood1 = Kettle("kenwood1", 8)  # Creating instance/object of class
# kenwood1.price = 30
# print("*" * 60)
# kenwood2 = Kettle("kenwood2", 9)
# # print("name: {}, price: {}, on: {} ".format(kenwood2.name, kenwood2.price, kenwood2.on)) # Or
# print("{0.name} = {0.price} = {0.on}, {1.name} = {1.price} = {1.on}".format(kenwood1, kenwood2))
# print(kenwood1.switch_on())  # Calling Method
#
# kenwood1.power = kenwood1.price # Can create a variable outside a class
# print(kenwood1.power)
#
# print(Kettle.power_source)
# print(kenwood1.power_source)
# print(kenwood2.power_source)
# print("*" * 30)
# Kettle.power_source = "Atomic"
# print(Kettle.power_source)
# print(kenwood1.power_source)
# print(kenwood2.power_source)
# print("*" * 60)
# # print(Kettle.__dict__)
# # print(kenwood1.__dict__)
# # print(kenwood2.__dict__)
# print(Kettle.power_source)
# print(kenwood1.power_source)
# print(kenwood2.power_source)
# print("*" * 30)
# kenwood1.power_source = "Gas" # Changing/accessing static variable by instance is possible in Python
# print(Kettle.power_source)
# print(kenwood1.power_source)
# print(kenwood2.power_source)
