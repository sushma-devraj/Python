import datetime
import pytz


class AccountOperation:
    """Simple class to deposit/withdraw and check account balance"""
    def __init__(self, name, balance):  # self as this in c++/java
        self.__name = name  # __variable name will become non public(Private)
        self.__balance = balance
        self.txn_list = []
        print("Account created for {} and initial balance is {}".format(self.__name, self.__balance))

    def deposit(self, amount):
        if amount > 0:
            self.__balance += amount
            self.txn_list.append((pytz.utc.localize(datetime.datetime.utcnow()), amount, "deposited"))
            self.show_txn()
            self.__show_balance()
        else:
            print("Invalid amount!!!")

    def withdraw(self, amount):
        if 0 < amount <= self.__balance:
            self.__balance -= amount
            self.txn_list.clear()
            self.txn_list.append((pytz.utc.localize(datetime.datetime.utcnow()), -amount, "withdrawn"))
            self.show_txn()
            self.__show_balance()
        else:
            print("Sorry can't withdraw:")
            self.__show_balance()

    def __show_balance(self):
        print("Available balance: {}rs".format(self.__balance))

    def show_txn(self):
        for date, amount, tran_type in self.txn_list:
            print("{} {} on {} (local time was {})".format(amount, tran_type, date, date.astimezone()))


if __name__ == '__main__':
    account1 = AccountOperation("Sonu", 0)
    print()
    account1.__balance = 900  # Since __balance is non public cannot over write outside class
    account1.deposit(500)
    print()
    account1.withdraw(300)
    account1.__balance = 900  # Since __balance is non public cannot over write outside class
    print(account1.__dict__)
    # account1.__show_balance()  # Cannot access private method outside class
