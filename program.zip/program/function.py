def fact(i):
    if i == 1:
        return i
    else:
        return (i * fact(i - 1))
    
num=int(input("Enter number: "))

with open("factorial", mode="w") as facto:
    print("factorial of {} is".format(num),fact(num), file=facto, sep=":")
