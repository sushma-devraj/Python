# Normal list
list1 = []
for i in range(10):
    list1.append(i) # or print(i)
print(list1)

# List comprehension
list2 = [i for i in range(10)]
print(list2)
# or
for i in list2:
    print(i, end=' ')

print()

# Generator expression
gen = (i for i in range(10))
for i in gen:
    print(i, end=' ')

print()
# Compare efficiency
from sys import getsizeof

comp = [i for i in range(10)]
print(getsizeof(comp))
gen = (i for i in range(10))  # More efficient
print(getsizeof(gen))
