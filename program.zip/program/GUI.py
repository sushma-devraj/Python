import tkinter

top = tkinter.Tk()
top.geometry("250x250")

B = tkinter.Button(top, text = "Click", bg='gray')
B.place(x = 100,y = 100)

top.mainloop()
