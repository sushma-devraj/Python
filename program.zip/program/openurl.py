import webbrowser
try:
    webbrowser.open_new('https://docs.python.org/3/tutorial/index.html')
except Exception:
    print(Exception.__traceback__)
