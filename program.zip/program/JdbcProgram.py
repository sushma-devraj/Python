import sqlite3

global fetch
global db

try:
    db = sqlite3.connect("sqlite connection")
    db.execute("CREATE TABLE IF NOT EXISTS contacts (name TEXT, number INTEGER)")

    db.execute("INSERT INTO contacts(name, number) VALUES('Sonu', 123456789)")
    db.execute("INSERT INTO contacts VALUES('Monu', 123456789)")
    db.execute("INSERT INTO contacts VALUES('Tonu', 123456789)")

    fetch = db.cursor()
    name = input("Enter name")
    fetch.execute("SELECT * FROM contacts WHERE name = ?",(name,))
    for row in fetch:
        print(row)
    # or
    print("Fetching all")
    fetch.execute("SELECT * FROM contacts")
    for row in fetch:
        print(row)
    # print(fetch.fetchall())  # Or

except Exception as e:
    print(e)
finally:
    fetch.close()
    db.close()




