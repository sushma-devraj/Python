dic = {1:"one", 2:"two", 3:"three", 4:"four"}
print(dic.get("two"))
print(dic)
print(dic.keys())
print(dic.values())
